@echo off
setlocal EnableDelayedExpansion
title windows11upgradechecker
color 0A

echo ==========================================
echo        Windows 11 Upgrade Checker
echo ==========================================
echo.

set SCORE=0
set TOTAL=7

:: 64-bit OS
if /I "%PROCESSOR_ARCHITECTURE%"=="AMD64" (
    echo [PASS] 64-bit Architecture
    set /a SCORE+=1
) else (
    echo [FAIL] 64-bit Architecture
)

:: RAM
for /f "skip=1" %%A in ('wmic computersystem get TotalPhysicalMemory 2^>nul') do (
    set RAM=%%A
    goto :RAMDONE
)

:RAMDONE
if defined RAM (
    set /a RAMGB=!RAM:~0,-9!
    if !RAMGB! GEQ 4 (
        echo [PASS] RAM: !RAMGB! GB
        set /a SCORE+=1
    ) else (
        echo [FAIL] RAM: !RAMGB! GB (Need 4+ GB)
    )
) else (
    echo [FAIL] Could not determine RAM
)

:: Storage
for /f "skip=1" %%A in ('wmic logicaldisk where "DeviceID='C:'" get Size 2^>nul') do (
    set DISK=%%A
    goto :DISKDONE
)

:DISKDONE
if defined DISK (
    set /a DISKGB=!DISK:~0,-9!
    if !DISKGB! GEQ 64 (
        echo [PASS] Storage: !DISKGB! GB
        set /a SCORE+=1
    ) else (
        echo [FAIL] Storage: !DISKGB! GB (Need 64+ GB)
    )
) else (
    echo [FAIL] Could not determine storage
)

:: CPU Cores
for /f "skip=1" %%A in ('wmic cpu get NumberOfCores 2^>nul') do (
    set CORES=%%A
    goto :COREDONE
)

:COREDONE
if defined CORES (
    if !CORES! GEQ 2 (
        echo [PASS] CPU Cores: !CORES!
        set /a SCORE+=1
    ) else (
        echo [FAIL] CPU Cores: !CORES! (Need 2+)
    )
)

:: CPU Speed
for /f "skip=1" %%A in ('wmic cpu get MaxClockSpeed 2^>nul') do (
    set SPEED=%%A
    goto :SPEEDDONE
)

:SPEEDDONE
if defined SPEED (
    if !SPEED! GEQ 1000 (
        echo [PASS] CPU Speed: !SPEED! MHz
        set /a SCORE+=1
    ) else (
        echo [FAIL] CPU Speed: !SPEED! MHz (Need 1000+)
    )
)

:: TPM 2.0
wmic /namespace:\\root\cimv2\security\microsofttpm path Win32_Tpm get SpecVersion 2>nul | find "2.0" >nul
if not errorlevel 1 (
    echo [PASS] TPM 2.0
    set /a SCORE+=1
) else (
    echo [FAIL] TPM 2.0
)

:: Secure Boot
reg query "HKLM\SYSTEM\CurrentControlSet\Control\SecureBoot\State" /v UEFISecureBootEnabled >nul 2>&1
if not errorlevel 1 (
    echo [PASS] Secure Boot Detected
    set /a SCORE+=1
) else (
    echo [FAIL] Secure Boot Not Detected
)

echo.
echo ==========================================
echo                EVALUATION
echo ==========================================
echo.

echo Overall Score: !SCORE!/!TOTAL!

if !SCORE! EQU !TOTAL! (
    echo Result: COMPATIBLE
    echo.
    echo This computer appears to meet all
    echo tested Windows 11 requirements.
) else (
    echo Result: NOT FULLY COMPATIBLE
    echo.
    echo One or more Windows 11 requirements
    echo were not met.
)

echo.
echo ==========================================
pause