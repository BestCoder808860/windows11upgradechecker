@echo off
title Windows 11 Upgrade Checker
color 0A

echo ==========================================
echo       Windows 11 Upgrade Checker
echo ==========================================
echo.

powershell -NoProfile -ExecutionPolicy Bypass ^
"$compatible=$true;" ^
"Write-Host 'Checking requirements...' -ForegroundColor Cyan;" ^
"" ^
"$os64=[Environment]::Is64BitOperatingSystem;" ^
"if($os64){Write-Host '[PASS] 64-bit Operating System' -ForegroundColor Green}else{Write-Host '[FAIL] 64-bit Operating System required' -ForegroundColor Red;$compatible=$false};" ^
"" ^
"$ram=[math]::Round((Get-CimInstance Win32_ComputerSystem).TotalPhysicalMemory/1GB,2);" ^
"if($ram -ge 4){Write-Host ('[PASS] RAM: '+$ram+' GB') -ForegroundColor Green}else{Write-Host ('[FAIL] RAM: '+$ram+' GB (Need 4 GB+)') -ForegroundColor Red;$compatible=$false};" ^
"" ^
"$disk=[math]::Round((Get-CimInstance Win32_LogicalDisk -Filter ""DeviceID='C:'"").Size/1GB,2);" ^
"if($disk -ge 64){Write-Host ('[PASS] Storage: '+$disk+' GB') -ForegroundColor Green}else{Write-Host ('[FAIL] Storage: '+$disk+' GB (Need 64 GB+)') -ForegroundColor Red;$compatible=$false};" ^
"" ^
"try{$tpm=Get-Tpm;if($tpm.TpmPresent -and $tpm.SpecVersion -match '2.0'){Write-Host '[PASS] TPM 2.0 detected' -ForegroundColor Green}else{Write-Host '[FAIL] TPM 2.0 not detected' -ForegroundColor Red;$compatible=$false}}catch{Write-Host '[FAIL] TPM information unavailable' -ForegroundColor Red;$compatible=$false};" ^
"" ^
"try{$sb=Confirm-SecureBootUEFI;if($sb){Write-Host '[PASS] Secure Boot enabled' -ForegroundColor Green}else{Write-Host '[FAIL] Secure Boot disabled' -ForegroundColor Red;$compatible=$false}}catch{Write-Host '[FAIL] System not booted in UEFI mode' -ForegroundColor Red;$compatible=$false};" ^
"" ^
"$cpu=Get-CimInstance Win32_Processor;" ^
"if($cpu.NumberOfCores -ge 2){Write-Host ('[PASS] CPU Cores: '+$cpu.NumberOfCores) -ForegroundColor Green}else{Write-Host '[FAIL] CPU needs at least 2 cores' -ForegroundColor Red;$compatible=$false};" ^
"" ^
"$ghz=[math]::Round($cpu.MaxClockSpeed/1000,2);" ^
"if($ghz -ge 1){Write-Host ('[PASS] CPU Speed: '+$ghz+' GHz') -ForegroundColor Green}else{Write-Host '[FAIL] CPU must be at least 1 GHz' -ForegroundColor Red;$compatible=$false};" ^
"" ^
"Write-Host '';" ^
"Write-Host '==========================================' -ForegroundColor White;" ^
"if($compatible){Write-Host 'RESULT: Likely compatible with Windows 11' -ForegroundColor Green}else{Write-Host 'RESULT: One or more requirements failed' -ForegroundColor Red};" ^
"Write-Host '==========================================' -ForegroundColor White"

echo.
pause